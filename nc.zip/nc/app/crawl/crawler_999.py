'''
Copyright (c) 2014 http://9miao.com All rights reserved.
'''

class Crawler_999:
	
	def catalogue(self,p_url):
		return "error url1: catalogue"

	def content(self,p_url):
		return "error url2: content"
