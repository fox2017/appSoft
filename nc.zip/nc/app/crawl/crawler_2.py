#coding:utf8
'''
Copyright (c) 2014 http://9miao.com All rights reserved.
'''

# from pyquery import PyQuery as pq
# import urllib

class Crawler_2:
	""" 
	"""

	def search(self,p_bookname="",p_author=""):
		return ""

	def catalogue(self,p_url):
		return "catalogue"

	def content(self,p_url):
		return "content"